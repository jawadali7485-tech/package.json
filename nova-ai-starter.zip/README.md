# NOVA AI

Free-to-users starter MVP for an all-in-one AI assistant.

## Included
- Chat UI
- Ideas, prompts, scripts, CV, cover-letter and email workflows through chat
- Responsive dark UI
- Server-side AI API route

## Run
1. Install Node.js 20+.
2. `npm install`
3. Copy `.env.example` to `.env.local`
4. Add your own `OPENAI_API_KEY`
5. `npm run dev`

Never expose your API key in client-side code or commit `.env.local`.
