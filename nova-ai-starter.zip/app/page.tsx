 "use client";
import {useState} from "react";

type Message={role:"user"|"assistant";content:string};

const actions=[
["💬","Ask anything"],["🎨","Create image"],["💡","Give me ideas"],
["✍️","Write a prompt"],["🎬","Write a script"],["📄","Create my CV"],
["✉️","Write an email"],["📎","Analyze a PDF"]
];

export default function Home(){
 const [input,setInput]=useState(""); const [messages,setMessages]=useState<Message[]>([]); const [loading,setLoading]=useState(false);
 async function send(){
  const text=input.trim(); if(!text||loading)return;
  const next=[...messages,{role:"user" as const,content:text}]; setMessages(next); setInput(""); setLoading(true);
  try{
   const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({messages:next})});
   const d=await r.json(); setMessages([...next,{role:"assistant",content:d.message||d.error||"Something went wrong."}]);
  }catch{setMessages([...next,{role:"assistant",content:"Please check your API setup and try again."}])}
  finally{setLoading(false)}
 }
 return <main className="min-h-screen">
  <header className="border-b border-white/10 px-5 py-4 flex items-center justify-between">
   <div><div className="text-xl font-bold">✦ NOVA AI</div><div className="text-xs text-gray-500">Ask. Create. Get It Done.</div></div>
   <button onClick={()=>setMessages([])} className="rounded-xl border border-white/10 px-4 py-2 text-sm hover:bg-white/10">New Chat</button>
  </header>
  <section className="mx-auto max-w-4xl px-5 py-8">
   {messages.length===0?<div className="min-h-[65vh] flex flex-col items-center justify-center text-center">
    <div className="mb-5 text-5xl">✦</div><h1 className="text-4xl md:text-6xl font-bold">What can I help you create?</h1>
    <p className="mt-4 max-w-2xl text-gray-400">Chat, ideas, prompts, scripts, CVs, emails, coding and more — all in one place.</p>
    <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-3 w-full">{actions.map(([icon,label])=><button key={label} onClick={()=>setInput(label)} className="rounded-2xl border border-white/10 bg-white/5 p-4 text-left hover:bg-white/10"><span className="mr-2">{icon}</span>{label}</button>)}</div>
   </div>:<div className="space-y-5 py-8">{messages.map((m,i)=><div key={i} className={m.role==="user"?"ml-auto max-w-[85%] rounded-2xl bg-purple-600 px-5 py-4":"mr-auto max-w-[85%] rounded-2xl border border-white/10 bg-white/5 px-5 py-4"}><div className="text-xs text-gray-300 mb-2">{m.role==="user"?"You":"NOVA AI"}</div><div className="whitespace-pre-wrap leading-7">{m.content}</div></div>)}{loading&&<div className="rounded-2xl border border-white/10 bg-white/5 px-5 py-4 text-gray-400">NOVA is thinking…</div>}</div>}
  </section>
  <footer className="sticky bottom-0 border-t border-white/10 bg-[#070812]/95 backdrop-blur px-5 py-4">
   <div className="mx-auto max-w-4xl flex gap-2 rounded-2xl border border-white/10 bg-white/5 p-2">
    <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{if(e.key==="Enter")send()}} placeholder="Ask NOVA anything…" className="min-w-0 flex-1 bg-transparent px-4 py-3 outline-none placeholder:text-gray-600"/>
    <button onClick={send} disabled={loading||!input.trim()} className="rounded-xl bg-purple-600 px-5 py-3 font-semibold disabled:opacity-40">{loading?"…":"Send"}</button>
   </div>
   <div className="text-center text-[11px] text-gray-600 mt-2">NOVA AI can make mistakes. Verify important information.</div>
  </footer>
 </main>
}