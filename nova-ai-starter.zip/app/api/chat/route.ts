import OpenAI from "openai";
import {NextResponse} from "next/server";

export async function POST(req:Request){
 try{
  const {messages}=await req.json();
  if(!process.env.OPENAI_API_KEY)return NextResponse.json({error:"OPENAI_API_KEY is missing in .env.local"},{status:500});
  const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
  const response=await client.responses.create({
   model:"gpt-5",
   instructions:`You are NOVA AI, a helpful all-in-one assistant. Help with questions, ideas, prompts, scripts, CVs/resumes, cover letters, emails, writing, coding, translation and productivity. Be clear, practical and professional.`,
   input:messages.map((m:{role:string,content:string})=>({role:m.role as "user"|"assistant",content:m.content}))
  });
  return NextResponse.json({message:response.output_text});
 }catch(e){console.error(e);return NextResponse.json({error:"AI request failed."},{status:500})}
}